export interface GenericResponse {
    status: string;
    httpStatus: string;
}
