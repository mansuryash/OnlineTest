export class UrlConstant {

public static get baseURL(): string { return "http://localhost:8090/OnlineTest/"; }
}

