export interface ITechnology {
    id: number;
    title: string;
}
