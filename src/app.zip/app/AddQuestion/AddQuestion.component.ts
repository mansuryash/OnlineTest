import { ITechnology } from './../ITechnology';
import { HttpServiceService } from './../HttpService.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-AddQuestion',
  templateUrl: './AddQuestion.component.html',
  styleUrls: ['./AddQuestion.component.css']
})
export class AddQuestionComponent implements OnInit {
  selected: ITechnology;

  technologyList: ITechnology[];

  constructor(private httpService: HttpServiceService) { }

  ngOnInit() {
    this.httpService.getAllTechnology().subscribe(res => {
      this.technologyList = res;
    });
  }

}
